USE btwnus; 

-- Afficher les produits les plus populaire chaque mois

SELECT 
    p.nom AS nom_produit,
    DATE_FORMAT(c.date_commande, '%Y-%m') AS mois,
    SUM(c.quantite) AS total_vendus
FROM 
    produits p
JOIN 
    commandes c ON p.id = c.produit_id
GROUP BY 
    p.id, mois
ORDER BY 
    mois, total_vendus DESC;


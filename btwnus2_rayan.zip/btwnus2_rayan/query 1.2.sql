USE btwnus; 

-- Afficher tous les produits.
SELECT * FROM produits ORDER BY prix ASC;


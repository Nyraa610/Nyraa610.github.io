USE btwnus;

-- Afficher tous les utilisateurs.
SELECT * FROM utilisateurs;








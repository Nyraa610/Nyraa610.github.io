USE btwnus; 

-- Afficher le nombre total des commandes passé par chaque utilisateur. 
SELECT 
    u.nom AS nom_utilisateur,
    COUNT(c.id) AS total_commandes
FROM 
    utilisateurs u
LEFT JOIN 
    commandes c ON u.id = c.utilisateur_id
GROUP BY 
    u.id, u.nom
ORDER BY 
    total_commandes DESC;

USE btwnus;

-- Afficher les produits acheté par utilisateur + deétails.
SELECT 
    u.nom AS nom_utilisateur,
    p.nom AS nom_produit,
    c.quantite,
    c.date_commande,
    p.prix
FROM 
    commandes c
JOIN 
    utilisateurs u ON c.utilisateur_id = u.id
JOIN 
    produits p ON c.produit_id = p.id
WHERE 
    u.nom = 'Alice Dupont';





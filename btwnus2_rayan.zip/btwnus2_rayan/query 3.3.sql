USE btwnus;

-- Afficher le client ayant depensé le plus dans la boutique

SELECT 
    u.nom AS nom_utilisateur,
    SUM(c.quantite * p.prix) AS total_depensé
FROM 
    utilisateurs u
JOIN 
    commandes c ON u.id = c.utilisateur_id
JOIN 
    produits p ON c.produit_id = p.id
GROUP BY 
    u.id, u.nom
ORDER BY 
    total_depensé DESC
LIMIT 1;

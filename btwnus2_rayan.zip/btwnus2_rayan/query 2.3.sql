USE btwnus;

-- Afficher les produits les plus vendus.
SELECT 
    p.nom AS nom_produit,
    SUM(c.quantite) AS total_vendus
FROM 
    produits p
JOIN 
    commandes c ON p.id = c.produit_id
GROUP BY 
    p.id, p.nom
ORDER BY 
    total_vendus DESC;

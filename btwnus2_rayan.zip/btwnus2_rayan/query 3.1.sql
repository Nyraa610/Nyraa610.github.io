USE btwnus; 

-- Liste des utilisateurs ayant passé au moins une commande

SELECT 
    u.id,
    u.nom
FROM 
    utilisateurs u
WHERE 
    u.id IN (SELECT DISTINCT c.utilisateur_id FROM commandes c);


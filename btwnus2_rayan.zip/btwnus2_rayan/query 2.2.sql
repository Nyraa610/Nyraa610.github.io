USE btwnus;

-- Calculer le prix total des commandes passé d’un utilisateur.
SELECT 
    u.nom AS nom_utilisateur,
    SUM(c.quantite * p.prix) AS total_commandes
FROM 
    utilisateurs u
JOIN 
    commandes c ON u.id = c.utilisateur_id
JOIN 
    produits p ON c.produit_id = p.id
WHERE 
    u.nom = 'Alice Dupont'
    




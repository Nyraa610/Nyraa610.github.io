USE btwnus; 

-- Afficher les commandes d'un utilisateur spécifique.
SELECT c.*, u.nom AS nom_utilisateur, p.nom AS nom_produit 
FROM commandes c
JOIN utilisateurs u ON c.utilisateur_id = u.id
JOIN produits p ON c.produit_id = p.id
WHERE u.nom = 'Alice Dupont';

